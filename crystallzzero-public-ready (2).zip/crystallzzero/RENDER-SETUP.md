# crystallzzero — Render setup

1. Put this project in a GitHub repository (do not upload `.env`).
2. In Render, create **New → Web Service** and connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Choose a paid web-service plan if you need persistent filesystem storage. Render persistent disks are available to paid web services.
6. Add a persistent disk mounted at `/var/data`.
7. Add these Environment variables:

```text
NODE_ENV=production
PORT=10000
DATA_DIR=/var/data
UPLOAD_DIR=/var/data/uploads
SESSION_SECRET=<generate a long random secret>
OWNER_EMAIL=<your owner email>
OWNER_PASSWORD=<use a new private owner password>
GOOGLE_CLIENT_ID=<Google client ID>
GOOGLE_CLIENT_SECRET=<Google client secret>
GOOGLE_CALLBACK_URL=https://YOUR-SERVICE.onrender.com/auth/google/callback
```

8. Deploy. Render gives the service a public `onrender.com` URL.
9. In Google Cloud, add the exact HTTPS callback URL from step 7 to **Authorized redirect URIs**.
10. In Google Auth Platform → Audience, move the app from Testing to In production when you're ready for public Google sign-in.

Never commit `.env`, client secrets, or the owner password to GitHub.
