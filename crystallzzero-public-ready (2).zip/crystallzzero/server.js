require('dotenv').config();

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'));
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(DATA_DIR, 'uploads'));
const DB_FILE = path.join(DATA_DIR, 'database.json');

for (const dir of [DATA_DIR, UPLOAD_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

// Simple JSON-backed persistent database. This avoids native database build
// requirements, making local Windows setup much easier. It can later be
// replaced with SQLite/Postgres without changing the frontend API.
const emptyDatabase = () => ({
  nextUserId: 1,
  nextLevelId: 1,
  users: [],
  levels: []
});

function loadDatabase() {
  try {
    if (!fs.existsSync(DB_FILE)) return emptyDatabase();
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return {
      nextUserId: Number(parsed.nextUserId) || 1,
      nextLevelId: Number(parsed.nextLevelId) || 1,
      users: Array.isArray(parsed.users) ? parsed.users : [],
      levels: Array.isArray(parsed.levels) ? parsed.levels : []
    };
  } catch (error) {
    console.error('Could not read database.json:', error);
    return emptyDatabase();
  }
}

let db = loadDatabase();

function saveDatabase() {
  const tempFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(db, null, 2), 'utf8');
  fs.renameSync(tempFile, DB_FILE);
}

if (!fs.existsSync(DB_FILE)) saveDatabase();

// The owner password is only read from the private environment variable.
// It is never sent to the frontend, logged, or embedded in UI/source served
// to website visitors.
function ensureOwnerAccount() {
  const email = String(process.env.OWNER_EMAIL || '').trim().toLowerCase();
  const password = String(process.env.OWNER_PASSWORD || '');
  if (!email || !password) return;

  let owner = db.users.find(user => user.email === email);
  if (!owner) {
    owner = {
      id: db.nextUserId++,
      email,
      display_name: 'Owner',
      avatar_url: null,
      google_id: null,
      password_hash: bcrypt.hashSync(password, 12),
      role: 'owner',
      created_at: new Date().toISOString(),
      last_login_at: null
    };
    db.users.push(owner);
    saveDatabase();
    return;
  }

  owner.password_hash = bcrypt.hashSync(password, 12);
  owner.role = 'owner';
  saveDatabase();
}

ensureOwnerAccount();

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: false
}));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false }));

app.use(session({
  name: 'crystallzzero.sid',
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

app.use(passport.initialize());
app.use(passport.session());

function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    email: user.email,
    display_name: user.display_name,
    avatar_url: user.avatar_url,
    role: user.role
  };
}

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser((id, done) => {
  const user = db.users.find(item => item.id === Number(id));
  done(null, user ? publicUser(user) : false);
});

const googleConfigured = Boolean(
  process.env.GOOGLE_CLIENT_ID &&
  process.env.GOOGLE_CLIENT_SECRET &&
  process.env.GOOGLE_CALLBACK_URL
);

if (googleConfigured) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: process.env.GOOGLE_CALLBACK_URL
  }, (accessToken, refreshToken, profile, done) => {
    try {
      const email = profile.emails?.[0]?.value?.toLowerCase();
      if (!email) return done(new Error('Google did not provide an email address.'));

      const ownerEmail = String(process.env.OWNER_EMAIL || '').trim().toLowerCase();
      const isOwner = email === ownerEmail && Boolean(ownerEmail);
      let existing = db.users.find(user => user.email === email);

      if (existing) {
        existing.display_name = profile.displayName || existing.display_name || 'Geometry Dash player';
        existing.avatar_url = profile.photos?.[0]?.value || existing.avatar_url || null;
        existing.google_id = profile.id;
        existing.role = isOwner ? 'owner' : existing.role;
        existing.last_login_at = new Date().toISOString();
      } else {
        existing = {
          id: db.nextUserId++,
          email,
          display_name: profile.displayName || 'Geometry Dash player',
          avatar_url: profile.photos?.[0]?.value || null,
          google_id: profile.id,
          password_hash: null,
          role: isOwner ? 'owner' : 'user',
          created_at: new Date().toISOString(),
          last_login_at: new Date().toISOString()
        };
        db.users.push(existing);
      }

      saveDatabase();
      done(null, publicUser(existing));
    } catch (error) {
      done(error);
    }
  }));
}

const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: 'draft-8',
  legacyHeaders: false
});
app.use('/api/', generalLimiter);

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => {
      const safeExt = path.extname(file.originalname).toLowerCase().slice(0, 10) || '.img';
      cb(null, `${Date.now()}-${crypto.randomUUID()}${safeExt}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);
    cb(null, allowed.has(file.mimetype));
  }
});

function requireUser(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'You need to sign in first.' });
  next();
}

function requireOwner(req, res, next) {
  if (!req.user || req.user.role !== 'owner') {
    return res.status(403).json({ error: 'Owner access required.' });
  }
  next();
}

function escapeXml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;');
}

function makeGeneratedThumbnail(levelName, levelId, difficulty) {
  const title = escapeXml(levelName.slice(0, 26) || 'Unnamed Challenge');
  const id = escapeXml(levelId);
  const diff = escapeXml(difficulty);
  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#111327"/>
        <stop offset="50%" stop-color="#202761"/>
        <stop offset="100%" stop-color="#0c0e19"/>
      </linearGradient>
      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
        <path d="M40 0H0V40" fill="none" stroke="#7cf7ff" stroke-opacity=".07" stroke-width="1"/>
      </pattern>
      <filter id="glow"><feGaussianBlur stdDeviation="8" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>
    <rect width="640" height="360" fill="url(#bg)"/>
    <rect width="640" height="360" fill="url(#grid)"/>
    <g filter="url(#glow)">
      <path d="M60 260 L150 170 L240 260 L330 170 L420 260 L510 170 L580 230" fill="none" stroke="#7cf7ff" stroke-width="5"/>
      <path d="M120 90 L150 60 L180 90 L150 120 Z" fill="#a87cff" fill-opacity=".85"/>
    </g>
    <rect x="32" y="28" width="576" height="304" rx="24" fill="none" stroke="#ffffff" stroke-opacity=".11"/>
    <text x="48" y="70" fill="#ffffff" font-size="18" font-family="Arial, sans-serif" font-weight="700" letter-spacing="3">CRYSTALLZZERO</text>
    <text x="48" y="248" fill="#ffffff" font-size="34" font-family="Arial, sans-serif" font-weight="800">${title}</text>
    <text x="48" y="284" fill="#cfd5ff" font-size="18" font-family="Arial, sans-serif">ID ${id}</text>
    <text x="48" y="312" fill="#7cf7ff" font-size="17" font-family="Arial, sans-serif" font-weight="700">${diff}</text>
  </svg>`;
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
}

app.get('/auth/google', (req, res, next) => {
  if (!googleConfigured) return res.redirect('/?error=google_not_configured');
  passport.authenticate('google', { scope: ['profile', 'email'] })(req, res, next);
});

app.get('/auth/google/callback', (req, res, next) => {
  if (!googleConfigured) return res.redirect('/?error=google_not_configured');
  passport.authenticate('google', {
    failureRedirect: '/?error=google_signin_failed'
  })(req, res, () => res.redirect('/'));
});

app.post('/auth/logout', (req, res, next) => {
  req.logout(error => {
    if (error) return next(error);
    req.session.destroy(() => res.json({ ok: true }));
  });
});

app.post('/auth/owner', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }), (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.users.find(item => item.email === email && item.role === 'owner');

  if (!user || !user.password_hash || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Owner sign-in failed.' });
  }

  req.login(publicUser(user), error => {
    if (error) return res.status(500).json({ error: 'Could not start the session.' });
    res.json({ ok: true });
  });
});

app.get('/api/config', (_req, res) => {
  res.json({ googleConfigured, siteName: 'crystallzzero' });
});

app.get('/api/me', (req, res) => {
  if (!req.user) return res.json({ user: null });
  res.json({ user: req.user });
});

app.get('/api/levels', (_req, res) => {
  const rows = [...db.levels].sort((a, b) => b.id - a.id);
  res.json({ levels: rows });
});

app.post('/api/levels', requireUser, upload.single('thumbnail'), (req, res) => {
  try {
    const levelName = String(req.body.levelName || '').trim();
    const levelId = String(req.body.levelId || '').trim();
    const difficulty = String(req.body.difficulty || '').trim();

    if (!levelName || !levelId || !difficulty) {
      if (req.file) fs.rmSync(req.file.path, { force: true });
      return res.status(400).json({ error: 'Please complete all required level fields.' });
    }

    if (levelName.length > 80 || levelId.length > 30 || difficulty.length > 30) {
      if (req.file) fs.rmSync(req.file.path, { force: true });
      return res.status(400).json({ error: 'One or more fields are too long.' });
    }

    const thumbnailUrl = req.file
      ? `/uploads/${req.file.filename}`
      : makeGeneratedThumbnail(levelName, levelId, difficulty);

    const created = {
      id: db.nextLevelId++,
      user_id: req.user.id,
      level_name: levelName,
      level_id: levelId,
      difficulty,
      thumbnail_url: thumbnailUrl,
      created_at: new Date().toISOString()
    };

    db.levels.push(created);
    saveDatabase();
    res.status(201).json({ level: created });
  } catch (error) {
    console.error('Level submission error:', error);
    if (req.file) fs.rmSync(req.file.path, { force: true });
    res.status(500).json({ error: 'Could not submit the level.' });
  }
});

app.delete('/api/levels/:id', requireOwner, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Invalid level id.' });

  const index = db.levels.findIndex(level => level.id === id);
  if (index === -1) return res.status(404).json({ error: 'Level not found.' });

  const level = db.levels[index];
  if (level.thumbnail_url?.startsWith('/uploads/')) {
    const filePath = path.join(UPLOAD_DIR, path.basename(level.thumbnail_url));
    fs.rmSync(filePath, { force: true });
  }

  db.levels.splice(index, 1);
  saveDatabase();
  res.json({ ok: true });
});

app.get('/admin', requireOwner, (_req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'admin.html'));
});

app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d', fallthrough: false }));
app.use(express.static(PUBLIC_DIR));

app.use((error, _req, res, _next) => {
  if (error instanceof multer.MulterError || error?.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'Thumbnail must be an image no larger than 5 MB.' });
  }
  console.error(error);
  if (res.headersSent) return;
  res.status(500).json({ error: 'Unexpected server error.' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`crystallzzero running on port ${PORT}`);
  console.log(`Google OAuth: ${googleConfigured ? 'configured' : 'NOT configured'} (add values to .env)`);
});
