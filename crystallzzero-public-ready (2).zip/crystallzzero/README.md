# crystallzzero

A polished Geometry Dash challenge-list website built with vanilla HTML/CSS/JS on the frontend and Node.js + Express + SQLite on the backend.

## Included

- Empty challenge list on first run — no fake levels are seeded.
- Google OAuth sign-in.
- Signed-in user/profile state with sign-out.
- Submission gate: users must be signed in before submitting.
- Submission form containing exactly four fields: Level Name, Geometry Dash Level ID, Difficulty, Thumbnail.
- Optional image upload; if omitted, the server generates an SVG thumbnail from the submitted level details.
- persistent JSON backend storage so levels survive page refreshes/restarts.
- Owner/admin role with level deletion at `/admin`.
- Owner credentials are server-side only; the owner password is never rendered in the UI or placed in client-side JavaScript.
- Responsive dark gaming aesthetic with animated effects.

## Run locally

1. Install Node.js 20+.
2. In this folder, run:

```bash
npm install
```

3. Copy `.env.example` to `.env`.
4. Fill in `SESSION_SECRET`, the Google OAuth values, and the owner password in `.env`.
5. Run:

```bash
npm start
```

6. Open `http://localhost:3000`.

## Google OAuth setup

In Google Cloud Console, create an OAuth 2.0 Web application and add the exact redirect URI:

`http://localhost:3000/auth/google/callback`

Then put the client ID, client secret, and callback URL into `.env`.

For production, use your real HTTPS domain and set the matching production callback URL in both Google Cloud Console and `.env`.

## Owner/admin setup

Set these in the private `.env` file:

- `OWNER_EMAIL=fakeisnotreallol@gmail.com`
- `OWNER_PASSWORD=<the owner password you supplied privately>`

The server hashes the owner password with bcrypt when the app starts and stores only the hash in SQLite. The plaintext password is never sent to the browser, never displayed in the UI, and is not checked into source control.

The Google account using the owner email is also assigned the `owner` role when it signs in through Google OAuth.

The owner can use the normal Google sign-in flow, or the server has a direct owner authentication endpoint at `POST /auth/owner` for a future/private owner-login UI if desired.

## Data locations

- SQLite database: `data/crystallzzero.db`
- Uploaded thumbnails: `uploads/`

These are ignored by git through `.gitignore` so secrets and live data are not accidentally committed.

## Backend connection points

The frontend talks to these backend routes:

- `GET /api/me`
- `GET /api/levels`
- `POST /api/levels`
- `POST /auth/logout`
- `GET /auth/google`
- `GET /auth/google/callback`
- `DELETE /api/levels/:id` (owner only)

To replace SQLite with another database later, the SQL access is isolated in `server.js` around the user and level queries.


### Easiest Windows launch
Double-click `start.bat`. It installs dependencies and starts the site automatically. Then open `http://localhost:3000`.

The local backend uses `data/database.json` for persistence instead of a native SQLite package, which avoids the common Windows `npm install` build error.


## Public deployment (Render)

This app can be deployed as a Render Node.js web service. The app stores its JSON database and uploaded thumbnails on the filesystem, so for persistence on Render, attach a persistent disk and set these environment variables:

- `DATA_DIR=/var/data`
- `UPLOAD_DIR=/var/data/uploads`
- `NODE_ENV=production`
- `PORT=10000`
- `SESSION_SECRET=<long-random-secret>`
- `OWNER_EMAIL=<owner email>`
- `OWNER_PASSWORD=<new private owner password>`
- `GOOGLE_CLIENT_ID=<your Google client ID>`
- `GOOGLE_CLIENT_SECRET=<your Google client secret>`
- `GOOGLE_CALLBACK_URL=https://YOUR-SERVICE.onrender.com/auth/google/callback`

Build command: `npm install`
Start command: `npm start`

For Google OAuth in production, replace the local callback URI in Google Cloud with the exact HTTPS URL above. Google requires production web OAuth redirect URIs to use HTTPS, and the redirect URI must match exactly.

Keep `.env` local and never commit it to GitHub. On Render, enter secrets in the service's Environment settings instead.
