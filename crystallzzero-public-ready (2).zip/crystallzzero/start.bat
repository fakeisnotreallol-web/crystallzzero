@echo off
cd /d "%~dp0"
echo Installing website dependencies...
npm install
if errorlevel 1 (
  echo.
  echo npm install failed. Make sure Node.js 20+ is installed.
  pause
  exit /b 1
)
echo.
echo Starting crystallzzero...
npm start
pause
