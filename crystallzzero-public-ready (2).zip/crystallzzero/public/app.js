const authArea = document.getElementById('authArea');
const submitButtons = [
  document.getElementById('submitTopBtn'),
  document.getElementById('submitHeroBtn'),
  document.getElementById('emptySubmitBtn')
].filter(Boolean);
const submissionModal = document.getElementById('submissionModal');
const closeModal = document.getElementById('closeModal');
const submissionForm = document.getElementById('submissionForm');
const formStatus = document.getElementById('formStatus');
const submitFormBtn = document.getElementById('submitFormBtn');
const levelGrid = document.getElementById('levelGrid');
const emptyState = document.getElementById('emptyState');
const levelCount = document.getElementById('levelCount');
const toast = document.getElementById('toast');

let currentUser = null;
let toastTimer;

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}

function renderAuth() {
  if (!currentUser) {
    authArea.innerHTML = '<a class="btn btn-primary" id="signInBtn" href="/auth/google">Sign In with Google</a>';
    return;
  }

  authArea.innerHTML = `
    <div class="user-menu" style="display:flex;align-items:center;gap:10px">
      <div style="display:flex;align-items:center;gap:9px;padding:6px 10px 6px 6px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:rgba(255,255,255,.035)">
        ${currentUser.avatar_url ? `<img src="${escapeHtml(currentUser.avatar_url)}" alt="" style="width:30px;height:30px;border-radius:10px;object-fit:cover">` : '<div style="width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,#76f5ff,#a78bff)"></div>'}
        <span style="font-size:12px;font-weight:700">${escapeHtml(currentUser.display_name || currentUser.email)}</span>
      </div>
      ${currentUser.role === 'owner' ? '<a class="btn btn-ghost" href="/admin">Admin</a>' : ''}
      <button class="btn btn-ghost" id="signOutBtn">Sign Out</button>
    </div>`;

  document.getElementById('signOutBtn')?.addEventListener('click', async () => {
    await fetch('/auth/logout', { method: 'POST' });
    currentUser = null;
    renderAuth();
    showToast('Signed out.');
  });
}

function openSubmissionModal() {
  if (!currentUser) {
    showToast('Please sign in first to submit a level.');
    document.getElementById('signInBtn')?.focus();
    return;
  }
  formStatus.textContent = '';
  submissionModal.hidden = false;
  document.body.style.overflow = 'hidden';
  submissionForm.querySelector('input[name="levelName"]')?.focus();
}

function closeSubmissionModal() {
  submissionModal.hidden = true;
  document.body.style.overflow = '';
}

submitButtons.forEach(button => button.addEventListener('click', openSubmissionModal));
closeModal?.addEventListener('click', closeSubmissionModal);
submissionModal?.addEventListener('click', event => {
  if (event.target === submissionModal) closeSubmissionModal();
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && !submissionModal.hidden) closeSubmissionModal();
});

async function loadLevels() {
  const data = await fetch('/api/levels').then(r => r.json());
  levelCount.textContent = String(data.levels.length);

  if (!data.levels.length) {
    emptyState.hidden = false;
    levelGrid.hidden = true;
    levelGrid.innerHTML = '';
    return;
  }

  emptyState.hidden = true;
  levelGrid.hidden = false;
  levelGrid.innerHTML = data.levels.map(level => `
    <article class="level-card">
      <img src="${escapeHtml(level.thumbnail_url)}" alt="${escapeHtml(level.level_name)} thumbnail" loading="lazy">
      <div class="level-body">
        <div class="level-difficulty">${escapeHtml(level.difficulty)}</div>
        <h3 class="level-title">${escapeHtml(level.level_name)}</h3>
        <div class="level-id">ID ${escapeHtml(level.level_id)}</div>
      </div>
    </article>
  `).join('');
}

submissionForm.addEventListener('submit', async event => {
  event.preventDefault();
  formStatus.textContent = '';
  submitFormBtn.disabled = true;
  submitFormBtn.textContent = 'Submitting…';

  try {
    const response = await fetch('/api/levels', {
      method: 'POST',
      body: new FormData(submissionForm)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Submission failed.');

    submissionForm.reset();
    closeSubmissionModal();
    showToast('Level submitted to the challenge list.');
    await loadLevels();
  } catch (error) {
    formStatus.textContent = error.message;
  } finally {
    submitFormBtn.disabled = false;
    submitFormBtn.textContent = 'Submit Level';
  }
});

async function init() {
  const [meResponse, configResponse] = await Promise.all([
    fetch('/api/me'),
    fetch('/api/config')
  ]);
  const me = await meResponse.json();
  const config = await configResponse.json();
  currentUser = me.user;
  renderAuth();
  await loadLevels();

  const url = new URL(window.location.href);
  const error = url.searchParams.get('error');
  if (error === 'google_not_configured') showToast('Google Sign-In is not configured yet. Add the OAuth values in .env.');
  if (error === 'google_signin_failed') showToast('Google Sign-In failed. Please try again.');
  if (error) {
    url.searchParams.delete('error');
    history.replaceState({}, '', url.pathname + url.search + url.hash);
  }

  if (!config.googleConfigured) {
    const signInBtn = document.getElementById('signInBtn');
    if (signInBtn) signInBtn.addEventListener('click', event => {
      event.preventDefault();
      showToast('Google Sign-In needs the owner OAuth configuration first.');
    });
  }
}

init().catch(error => {
  console.error(error);
  showToast('Could not load crystallzzero.');
});
