The website creates data/database.json automatically on first start.
This JSON file stores users and submitted levels persistently.
Keep this folder private on a public deployment.
